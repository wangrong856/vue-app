export default {
    notObj: {
        lang_name:"英",
        tips_name: "OOPS!",
        copyright_name: "All rights reserved",
        context_name: "The webmaster said that you can not enter this page...",
        to_home_name: "Please check that the URL you entered is correct, or click the button below to return to the homepage.",
        button_name: "Back to home",
    }
}