export default {
    notObj: {
        lang_name:"中",
        tips_name: "糟糕!",
        copyright_name: "版权所有",
        context_name: "站长说你不能进入这个页面...",
        to_home_name: "请检查您输入的网址是否正确，或点击下方按钮返回 首页。",
        button_name: "回到首页",
    }
}